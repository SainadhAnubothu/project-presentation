package com.cg.ems.exception;

public class EmployeeMaintenanceException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public EmployeeMaintenanceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeMaintenanceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
