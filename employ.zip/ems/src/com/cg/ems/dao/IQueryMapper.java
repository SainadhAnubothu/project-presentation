package com.cg.ems.dao;

public interface IQueryMapper {
	public static String IDSEARCH="SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,DEPT_NAME,EMP_GRADE,EMP_DESIGNATION FROM EMPLOYEE JOIN Department ON EMPLOYEE.EMP_DEPT_ID=DEPARTMENT.DEPT_ID WHERE EMP_ID=?";
	public static String FIRSTNAMESEARCH="SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,DEPT_NAME,EMP_GRADE,EMP_DESIGNATION FROM EMPLOYEE JOIN Department ON EMPLOYEE.EMP_DEPT_ID=DEPARTMENT.DEPT_ID WHERE EMP_FIRST_NAME=?";
	public static String LASTNAMESEARCH="SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,DEPT_NAME,EMP_GRADE,EMP_DESIGNATION FROM EMPLOYEE JOIN Department ON EMPLOYEE.EMP_DEPT_ID=DEPARTMENT.DEPT_ID WHERE EMP_LAST_NAME=?";
	public static String DEPTSEARCH="SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,DEPT_NAME,EMP_GRADE,EMP_DESIGNATION FROM EMPLOYEE JOIN Department ON EMPLOYEE.EMP_DEPT_ID=DEPARTMENT.DEPT_ID WHERE DEPT_NAME=?";
	public static String GRADESEARCH="SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,DEPT_NAME,EMP_GRADE,EMP_DESIGNATION FROM EMPLOYEE JOIN Department ON EMPLOYEE.EMP_DEPT_ID=DEPARTMENT.DEPT_ID WHERE EMP_GRADE=?";
	public static String MARITALSEARCH="SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,DEPT_NAME,EMP_GRADE,EMP_DESIGNATION FROM EMPLOYEE JOIN Department ON EMPLOYEE.EMP_DEPT_ID=DEPARTMENT.DEPT_ID WHERE EMP_MARITAL_STATUS=?";
	public static String LEAVEDETAILS="INSERT INTO LEAVE_HISTORY VALUES(seq_leave_id.nextval,?,?,?,?,?,?,default)";
	public static String USERTYPE="select user_type,user_id from user_master where user_name=? and user_password=?";
	public static String DAYS="select sysdate - (Select applied_date from leave_history  where leave_id =?) from dual";
	public static String ADDEMP="insert into employee values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static String CHECKEMPID="Select emp_id from employee where emp_id=?";
	public static String CHECKSALARY="Select min_salary,max_salary from grade_master where grade_code=?";
	public static String MODIFYEMP="update employee set emp_first_name=?,emp_last_name=?,emp_dept_id=?,emp_grade=?,emp_designation=?,emp_basic=?,emp_marital_status=?,emp_home_address=?,emp_contact_num=? where emp_id=?";
	public static String DISPLAYALL="SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,DEPT_NAME,EMP_GRADE,EMP_DESIGNATION FROM EMPLOYEE JOIN Department ON EMPLOYEE.EMP_DEPT_ID=DEPARTMENT.DEPT_ID ORDER BY EMPLOYEE.EMP_ID";
	public static String LEAVEDECISION="select l.leave_id,l.emp_id,l.leave_balance,l.noofdays_applied,l.date_from,l.date_to,l.applied_date,l.status from leave_history l ,Employee e where e.emp_id = l.emp_id and e.mgr_id=? and status='applied'";
	public static String APPROVELEAVE="update leave_history set status='approved',leave_balance=leave_balance-? where leave_id=?";
	public static String REJECTLEAVE="update leave_history set status='rejected' where leave_id=?";
}
